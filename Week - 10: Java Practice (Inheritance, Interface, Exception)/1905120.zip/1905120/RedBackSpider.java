public class RedBackSpider extends Arachnid {
    public RedBackSpider(String name, int age) {
        super(name, age);
    }
}
