public class Arachnid extends Animal {
    public Arachnid(String name, int age) {
        super(name, age);
    }
}
