public class Platypus extends Mammal {
    public Platypus(String name, int age) {
        super(name, age);
    }
}
