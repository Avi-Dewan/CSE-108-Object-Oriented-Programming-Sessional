public class FruitBat extends Mammal {
    public FruitBat(String name, int age) {
        String blood = "Warm";
        super(name, age, blood);
    }
}
