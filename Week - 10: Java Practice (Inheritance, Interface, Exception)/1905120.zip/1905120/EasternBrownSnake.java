public class EasternBrownSnake extends Reptile {
    public EasternBrownSnake(String name, int age) {
        super(name, age);
    }

}
