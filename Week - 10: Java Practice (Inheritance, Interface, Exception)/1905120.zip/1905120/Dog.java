public class Dog extends Mammal {
    public Dog(String name, int age) {
        super(name, age);
    }

}
